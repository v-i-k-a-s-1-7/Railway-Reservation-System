function openForm() {
    document.getElementById("myForm").style.display ="flex";
  }
function closeForm() {
    document.getElementById("myForm").style.display = "none";
  }
function alertDisplay()
  {
      window.alert("Sorry! No Train found on this route");
      document.getElementById("p2").innerHTML="Form Submittd ";
  
  } 
  function alertdisplay()
  {
      window.alert("Form submitted successfully!");
      document.getElementById("p2").innerHTML="Form Submittd ";
  
  }       